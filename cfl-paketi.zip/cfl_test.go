package main

import (
	"math"
	"math/rand"
	"testing"
)

// makeTriangle: üç istasyon, tam bağlı (kromatik sayı = 3).
func makeTriangle() []*BaseStation {
	a := NewBaseStation(0, 0, 0)
	b := NewBaseStation(1, 50, 0)
	c := NewBaseStation(2, 25, 40)
	for _, pair := range [][2]*BaseStation{{a, b}, {b, c}, {a, c}} {
		w := pathGain(Distance(pair[0], pair[1]))
		pair[0].NeighborWeights[pair[1].ID] = w
		pair[1].NeighborWeights[pair[0].ID] = w
	}
	return []*BaseStation{a, b, c}
}

// Test 1: iki komşu, K=2 — hızla yakınsamalı, renkler farklı olmalı.
func TestCFLTwoNeighbors(t *testing.T) {
	net := makePair(30)
	rng := rand.New(rand.NewSource(7))
	assign, rounds, converged := RunCFL(net, 2, CFLDefaultB, CFLMaxRounds, rng)
	if !converged {
		t.Fatal("iki komşu K=2'de yakınsamalıydı")
	}
	if assign[0] == assign[1] {
		t.Errorf("yakınsadı ama renkler aynı: %v", assign)
	}
	if rounds > 100 {
		t.Errorf("iki düğüm için %d tur çok fazla", rounds)
	}
}

// Test 2 (negatif kontrol): üçgen, K=2 — kromatik sayı 3 > 2, ASLA yakınsamamalı.
func TestCFLTriangleK2NeverConverges(t *testing.T) {
	net := makeTriangle()
	rng := rand.New(rand.NewSource(7))
	_, _, converged := RunCFL(net, 2, CFLDefaultB, 200, rng)
	if converged {
		t.Fatal("üçgen K=2'de yakınsama imkansız; success kontrolü hatalı olabilir (senkronluk tuzağı?)")
	}
}

// Test 3: failure güncellemesi olasılık kütlesini korumalı, negatif üretmemeli.
func TestCFLProbabilityInvariant(t *testing.T) {
	rng := rand.New(rand.NewSource(3))
	p := []float64{0.25, 0.25, 0.25, 0.25}
	for step := 0; step < 1000; step++ {
		cflApplyFailureUpdate(p, PRB(rng.Intn(4)), CFLDefaultB)
		sum := 0.0
		for _, x := range p {
			if x < 0 {
				t.Fatalf("adım %d: negatif olasılık %v", step, p)
			}
			sum += x
		}
		if math.Abs(sum-1.0) > 1e-9 {
			t.Fatalf("adım %d: olasılık toplamı %.12f != 1", step, sum)
		}
	}
}

// Test 4: aynı seed aynı sonucu vermeli (tekrarlanabilirlik).
func TestCFLReproducible(t *testing.T) {
	run := func() ([]PRB, int, bool) {
		rng := rand.New(rand.NewSource(11))
		net := BuildNetwork(rand.New(rand.NewSource(5)), 15, 300, 100, false)
		return RunCFL(net, 4, CFLDefaultB, CFLMaxRounds, rng)
	}
	a1, r1, c1 := run()
	a2, r2, c2 := run()
	if r1 != r2 || c1 != c2 {
		t.Fatalf("tur/converged farklı: (%d,%v) vs (%d,%v)", r1, c1, r2, c2)
	}
	for i := range a1 {
		if a1[i] != a2[i] {
			t.Fatalf("atama farklı: istasyon %d: %d vs %d", i, a1[i], a2[i])
		}
	}
}

// Test 5: boru hattı uyumu — üçgen K=3 yakınsayınca AssignmentCost tam 0 olmalı.
func TestCFLPipelineCompatible(t *testing.T) {
	net := makeTriangle()
	rng := rand.New(rand.NewSource(7))
	assign, _, converged := RunCFL(net, 3, CFLDefaultB, CFLMaxRounds, rng)
	if !converged {
		t.Fatal("üçgen K=3'te yakınsamalıydı")
	}
	if cost := AssignmentCost(net, assign); cost != 0 {
		t.Errorf("yakınsamış CFL atamasının maliyeti 0 olmalı, %.3e çıktı", cost)
	}
}
